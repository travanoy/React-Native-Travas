Mouse Fix (DINPUT8.DLL)
-------------------------------------------------------------
Фикс исправляет неработающую мышь в игре.
Ничего не требует.
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Der Autor: viggoman
Auf der Site vom Benutzer hinzugefuegt wurde: Camel
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
